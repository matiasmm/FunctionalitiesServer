<?php

namespace App\ServerBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AppServerBundle extends Bundle
{
}
