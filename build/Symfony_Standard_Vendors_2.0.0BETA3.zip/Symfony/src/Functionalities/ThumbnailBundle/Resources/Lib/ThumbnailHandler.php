<?php
namespace Functionalities;

class ThumbnailHandler{
    
}
