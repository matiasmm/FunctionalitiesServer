<?php

namespace Functionalities\ThumbnailBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ThumbnailBundle extends Bundle
{
}
